import React, { useState, useEffect, useRef } from 'react';
import { ParticipantProfile, VideoCallSession } from '../types';
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Phone, 
  PhoneOff, 
  ShieldCheck, 
  CheckCircle2, 
  User, 
  Volume2, 
  Monitor, 
  PhoneCall,
  Globe2,
  Lock
} from 'lucide-react';

interface DirectVideoVoiceConnectionProps {
  currentParticipant: ParticipantProfile;
  onOpenBiometricsModal: () => void;
}

export const DirectVideoVoiceConnection: React.FC<DirectVideoVoiceConnectionProps> = ({
  currentParticipant,
  onOpenBiometricsModal
}) => {
  const [activeSession, setActiveSession] = useState<VideoCallSession | null>(null);
  const [callTimer, setCallTimer] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [cameraPermissionGranted, setCameraPermissionGranted] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // International Direct Calling Contacts
  const contacts = [
    {
      id: 'CNT-01',
      name: 'Director General of Foreign Trade',
      role: 'Ministry of Trade & Regional Integration',
      country: 'Ethiopia (Addis Ababa)',
      avatar: '/src/assets/images/avatar_director_zebene_1790671691311.jpg',
      status: 'Available for Direct Video'
    },
    {
      id: 'CNT-02',
      name: 'Commercial Bank of Ethiopia (CBE) Clearing Directorate',
      role: 'Interbank Liquidity & ISO 20022 Settlements',
      country: 'Ethiopia (Headquarters)',
      avatar: '/src/assets/images/avatar_director_zebene_1790671691311.jpg',
      status: 'Active Clearing Desk'
    },
    {
      id: 'CNT-03',
      name: 'African Development Bank Trade Envoy',
      role: 'Pan-African Sovereign Credit & Trade Escrow',
      country: 'Regional Corridors',
      avatar: '/src/assets/images/avatar_director_zebene_1790671691311.jpg',
      status: 'Connected'
    },
    {
      id: 'CNT-04',
      name: 'Antwerp Global Coffee Importers NV',
      role: 'European Commodity Trade Directorate',
      country: 'Belgium / European Hub',
      avatar: '/src/assets/images/avatar_director_zebene_1790671691311.jpg',
      status: 'Online'
    }
  ];

  // Call timer effect
  useEffect(() => {
    let interval: any;
    if (activeSession && activeSession.status === 'connected') {
      interval = setInterval(() => {
        setCallTimer(prev => prev + 1);
      }, 1000);
    } else {
      setCallTimer(0);
    }
    return () => clearInterval(interval);
  }, [activeSession]);

  // Request actual camera/mic if supported and available
  const startCamera = async () => {
    if (typeof navigator !== 'undefined' && navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        mediaStreamRef.current = stream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
        setCameraPermissionGranted(true);
      } catch (err) {
        // Fallback simulated stream is gracefully used
        setCameraPermissionGranted(false);
      }
    }
  };

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
  };

  const handleStartCall = (contact: typeof contacts[0], type: 'video' | 'voice') => {
    startCamera();
    setActiveSession({
      id: `CALL-${Math.floor(1000 + Math.random() * 9000)}`,
      partnerName: contact.name,
      partnerRole: contact.role,
      partnerCountry: contact.country,
      avatar: contact.avatar,
      callType: type,
      status: 'calling',
      durationSeconds: 0,
      isMuted: false,
      isVideoEnabled: type === 'video'
    });

    setToastMessage(`Calling ${contact.name}... establishing end-to-end encrypted connection.`);

    // Connect after 1.5 seconds
    setTimeout(() => {
      setActiveSession(prev => prev ? { ...prev, status: 'connected' } : null);
      setToastMessage(`Connected with ${contact.name}!`);
    }, 1500);
  };

  const handleEndCall = () => {
    stopCamera();
    setActiveSession(prev => prev ? { ...prev, status: 'ended' } : null);
    setTimeout(() => setActiveSession(null), 1000);
    setToastMessage('Call ended. Connection closed securely.');
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getAudioTracks().forEach(t => {
        t.enabled = isMuted;
      });
    }
  };

  const toggleVideo = () => {
    setIsVideoEnabled(!isVideoEnabled);
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getVideoTracks().forEach(t => {
        t.enabled = !isVideoEnabled;
      });
    }
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-8">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-lg border border-amber-500/40 bg-slate-900 p-4 text-xs font-semibold text-amber-300 shadow-2xl">
          <CheckCircle2 className="h-4 w-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400">
            <span>Direct Global Telecommunication</span>
            <span aria-hidden="true">·</span>
            <span>Real-time End-to-End Encrypted</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
            Direct Video & Voice Connection Center
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
            Direct, crystal-clear video and voice communication connecting registered participants, foreign trade directorates, partner banks, and global trade buyers.
          </p>
        </div>

        {/* User Biometric Badge */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenBiometricsModal}
            className="flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3.5 py-2 text-xs text-amber-300 hover:bg-amber-500/20 transition-colors cursor-pointer"
          >
            <ShieldCheck className="h-4 w-4 text-amber-400" />
            <div className="text-left font-mono">
              <span className="text-[10px] text-slate-400 block">Participant Code:</span>
              <span className="font-bold text-white">{currentParticipant.codeNumber}</span>
            </div>
          </button>
        </div>
      </div>

      {/* Active Call Interface Viewport */}
      {activeSession && (
        <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6 shadow-2xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="flex h-3 w-3 rounded-full bg-emerald-500 animate-ping" />
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white font-sans">{activeSession.partnerName}</span>
                  <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                    <Lock className="h-3 w-3" /> E2EE Secured
                  </span>
                </div>
                <span className="text-xs text-slate-400">{activeSession.partnerRole} · {activeSession.partnerCountry}</span>
              </div>
            </div>

            <div className="flex items-center gap-3 text-xs font-mono">
              <span className="text-amber-400 font-bold tabular-nums text-sm bg-slate-900 px-3 py-1 rounded-lg border border-slate-800">
                {formatTimer(callTimer)}
              </span>
              <span className="text-slate-400 uppercase text-[10px]">{activeSession.callType.toUpperCase()} MODE</span>
            </div>
          </div>

          {/* Video Frames Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-72 sm:h-96">
            {/* Remote Partner Stream */}
            <div className="relative rounded-xl overflow-hidden bg-slate-900 border border-slate-800 flex items-center justify-center">
              <img
                src={activeSession.avatar}
                alt={activeSession.partnerName}
                className="h-full w-full object-cover opacity-80"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />

              <div className="absolute bottom-4 left-4 flex items-center gap-2 text-xs font-medium text-white bg-slate-950/80 px-3 py-1.5 rounded-lg border border-slate-800 backdrop-blur-sm">
                <span>{activeSession.partnerName}</span>
                <span className="text-emerald-400">● 1080p HD</span>
              </div>

              {/* Animated audio waves */}
              <div className="absolute top-4 right-4 flex items-center gap-1 bg-slate-950/80 px-2.5 py-1 rounded-md border border-slate-800">
                <Volume2 className="h-3.5 w-3.5 text-amber-400" />
                <div className="flex items-end gap-0.5 h-3">
                  <span className="w-1 bg-amber-400 rounded h-2 animate-bounce" />
                  <span className="w-1 bg-amber-400 rounded h-3 animate-pulse" />
                  <span className="w-1 bg-amber-400 rounded h-1 animate-bounce" />
                </div>
              </div>
            </div>

            {/* Local Participant Stream */}
            <div className="relative rounded-xl overflow-hidden bg-slate-900 border border-slate-800 flex items-center justify-center">
              {isVideoEnabled ? (
                cameraPermissionGranted ? (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="h-full w-full object-cover transform scale-x-[-1]"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-center p-6 space-y-2">
                    <div className="h-16 w-16 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-amber-400">
                      <User className="h-8 w-8" />
                    </div>
                    <span className="text-sm font-semibold text-white">{currentParticipant.fullName}</span>
                    <span className="text-xs text-slate-400 font-mono">Participant Code: {currentParticipant.codeNumber}</span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      Verified Thumb & Eye Print Verified
                    </span>
                  </div>
                )
              ) : (
                <div className="flex flex-col items-center justify-center text-center p-6 space-y-2 text-slate-500">
                  <VideoOff className="h-10 w-10 text-slate-600" />
                  <span className="text-xs">Camera is muted</span>
                </div>
              )}

              <div className="absolute bottom-4 left-4 flex items-center gap-2 text-xs font-medium text-white bg-slate-950/80 px-3 py-1.5 rounded-lg border border-slate-800 backdrop-blur-sm">
                <span>You ({currentParticipant.fullName})</span>
                {isMuted && <span className="text-rose-400 font-bold">Muted</span>}
              </div>
            </div>
          </div>

          {/* Call Control Toolbar */}
          <div className="flex items-center justify-center gap-4 pt-2">
            <button
              onClick={toggleMute}
              className={`p-3.5 rounded-full border transition-colors cursor-pointer ${
                isMuted
                  ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                  : 'bg-slate-800 border-slate-700 text-white hover:bg-slate-700'
              }`}
              title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
            >
              {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </button>

            <button
              onClick={toggleVideo}
              className={`p-3.5 rounded-full border transition-colors cursor-pointer ${
                !isVideoEnabled
                  ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                  : 'bg-slate-800 border-slate-700 text-white hover:bg-slate-700'
              }`}
              title={isVideoEnabled ? 'Turn Off Camera' : 'Turn On Camera'}
            >
              {isVideoEnabled ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
            </button>

            <button
              onClick={handleEndCall}
              className="flex items-center gap-2 bg-rose-600 hover:bg-rose-500 text-white px-6 py-3.5 rounded-full text-xs font-bold uppercase tracking-wider transition-colors shadow-lg cursor-pointer"
            >
              <PhoneOff className="h-5 w-5" />
              <span>Disconnect Call</span>
            </button>
          </div>
        </div>
      )}

      {/* Directory of Direct Connections */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <h2 className="text-base font-bold text-white tracking-tight">
              Direct International Contact Directory
            </h2>
            <p className="text-xs text-slate-400">
              One-click instant video and voice communication with sovereign clearance
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
            <CheckCircle2 className="h-3.5 w-3.5" /> All Direct Lines Active
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {contacts.map((contact) => (
            <div
              key={contact.id}
              className="flex flex-col justify-between rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-4 hover:border-slate-700 transition-all shadow-sm"
            >
              <div className="flex items-start gap-3.5">
                <div className="h-12 w-12 rounded-xl overflow-hidden border border-slate-700 bg-slate-800 shrink-0">
                  <img
                    src={contact.avatar}
                    alt={contact.name}
                    className="h-full w-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="space-y-1 flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white leading-tight">
                      {contact.name}
                    </h3>
                  </div>

                  <p className="text-xs text-slate-400 leading-snug">
                    {contact.role}
                  </p>

                  <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono pt-0.5">
                    <Globe2 className="h-3 w-3 text-amber-400" />
                    <span>{contact.country}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-emerald-400">{contact.status}</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3">
                <button
                  onClick={() => handleStartCall(contact, 'video')}
                  className="flex-1 flex items-center justify-center gap-1.5 rounded-lg bg-amber-500 py-2.5 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors shadow-sm cursor-pointer"
                >
                  <Video className="h-4 w-4" />
                  <span>Direct Video Call</span>
                </button>

                <button
                  onClick={() => handleStartCall(contact, 'voice')}
                  className="flex-1 flex items-center justify-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 py-2.5 text-xs font-medium text-slate-200 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
                >
                  <Phone className="h-4 w-4 text-amber-400" />
                  <span>Voice Call</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
