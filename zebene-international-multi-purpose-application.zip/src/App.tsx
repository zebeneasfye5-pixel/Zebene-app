import React, { useState } from 'react';
import { 
  TabType, 
  Currency, 
  Language,
  ParticipantProfile,
  InformationItem, 
  IdeaItem, 
  TradeProduct, 
  TradeOrder, 
  BankConnector, 
  TaxRecord 
} from './types';
import { 
  INITIAL_INFORMATION, 
  INITIAL_IDEAS, 
  TRADE_PRODUCTS, 
  INITIAL_ORDERS, 
  CONNECTED_BANKS, 
  COMPLIANCE_LAWS, 
  INITIAL_TAX_RECORDS 
} from './data/mockData';
import { Header } from './components/Header';
import { AudioTranslationBar } from './components/AudioTranslationBar';
import { HeroOverview } from './components/HeroOverview';
import { DirectVideoVoiceConnection } from './components/DirectVideoVoiceConnection';
import { BiometricRegistrationModal } from './components/BiometricRegistrationModal';
import { InformationExchange } from './components/InformationExchange';
import { IdeaGiftGame } from './components/IdeaGiftGame';
import { ProductTrading } from './components/ProductTrading';
import { ExpenseToIncome } from './components/ExpenseToIncome';
import { BankConnectivity } from './components/BankConnectivity';
import { EthicalLegalLaws } from './components/EthicalLegalLaws';
import { TaxGovernmentPortal } from './components/TaxGovernmentPortal';
import { OwnerRevenueAnalytics } from './components/OwnerRevenueAnalytics';
import { ZebeneProcedureGuide } from './components/ZebeneProcedureGuide';
import { Footer } from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [currency, setCurrency] = useState<Currency>('USD');
  const [currentLanguage, setCurrentLanguage] = useState<Language>('en');

  // Participant Biometric Registration & Unique Code
  const [currentParticipant, setCurrentParticipant] = useState<ParticipantProfile>({
    codeNumber: 'ZAIC-ET-8942-019',
    fullName: 'Zebene Asfye',
    organization: 'Zebene Asfye International Communication Directorate',
    role: 'Director General & Founder',
    country: 'Ethiopia',
    thumbprintVerified: true,
    thumbprintHash: 'THUMB-RH-SHA256:7A9F02C1E8B4',
    eyeIrisVerified: true,
    eyeIrisHash: 'IRIS-RE-SHA256:4B1C98E3D7A0',
    registeredDate: '2026-09-29',
    accessTier: 'Government & Sovereign'
  });

  const [isBiometricsModalOpen, setIsBiometricsModalOpen] = useState(false);

  // Application State
  const [informationList, setInformationList] = useState<InformationItem[]>(INITIAL_INFORMATION);
  const [ideas, setIdeas] = useState<IdeaItem[]>(INITIAL_IDEAS);
  const [products] = useState<TradeProduct[]>(TRADE_PRODUCTS);
  const [orders, setOrders] = useState<TradeOrder[]>(INITIAL_ORDERS);
  const [banks, setBanks] = useState<BankConnector[]>(CONNECTED_BANKS);
  const [taxRecords, setTaxRecords] = useState<TaxRecord[]>(INITIAL_TAX_RECORDS);

  // Trade Modal Control
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);

  // Dynamic Financial Aggregations
  const totalTradingVolumeUSD = orders.reduce((sum, o) => sum + o.totalUSD, 0);
  const totalTaxRemittedUSD = taxRecords
    .filter(t => t.status === 'Remitted')
    .reduce((sum, t) => sum + t.taxDeductedUSD, 0);
  const totalOwnerRevenueUSD = orders.reduce((sum, o) => sum + o.ownerFeeUSD, 0);

  // Handlers
  const handleAddInformation = (item: InformationItem) => {
    setInformationList([item, ...informationList]);
  };

  const handleAddIdea = (idea: IdeaItem) => {
    setIdeas([idea, ...ideas]);
  };

  const handleGiftTokensToIdea = (ideaId: string, amount: number) => {
    setIdeas(prev => prev.map(i => {
      if (i.id === ideaId) {
        return {
          ...i,
          giftTokensReceived: i.giftTokensReceived + amount,
          impactScore: Math.min(100, i.impactScore + 1)
        };
      }
      return i;
    }));
  };

  const handleExecuteTrade = (newOrder: TradeOrder) => {
    setOrders([newOrder, ...orders]);

    // Automatically create the corresponding 15% VAT Tax Record for Government Remittance
    const newTaxRecord: TaxRecord = {
      id: `TAX-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      taxType: 'Value Added Tax (VAT 15%)',
      sourceTransaction: `${newOrder.id} (${newOrder.productName})`,
      grossAmountUSD: newOrder.totalUSD,
      taxRatePercent: 15.0,
      taxDeductedUSD: newOrder.taxAmountUSD,
      recipientEntity: 'Federal Ministry of Finance',
      status: 'Remitted',
      filingNumber: `ET-REV-VAT-${Math.floor(100000 + Math.random() * 900000)}-C`,
      date: newOrder.date
    };

    setTaxRecords([newTaxRecord, ...taxRecords]);
  };

  const handleAddBank = (newBank: BankConnector) => {
    setBanks([...banks, newBank]);
  };

  const handleRemitTax = (taxId: string) => {
    setTaxRecords(prev => prev.map(t => {
      if (t.id === taxId) {
        return { ...t, status: 'Remitted' };
      }
      return t;
    }));
  };

  const handleCompleteBiometricRegistration = (newProfile: ParticipantProfile) => {
    setCurrentParticipant(newProfile);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar Contract (3 Zones) */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currency={currency}
        setCurrency={setCurrency}
        onOpenTradeModal={() => {
          setActiveTab('trading');
          setIsTradeModalOpen(true);
        }}
        currentParticipant={currentParticipant}
        onOpenBiometricsModal={() => setIsBiometricsModalOpen(true)}
      />

      {/* Universal Translation & Voice Hear Bar */}
      <AudioTranslationBar
        currentLanguage={currentLanguage}
        onLanguageChange={setCurrentLanguage}
      />

      {/* Main Workspace Viewport */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        {activeTab === 'overview' && (
          <HeroOverview
            setActiveTab={setActiveTab}
            currency={currency}
            onOpenTradeModal={() => {
              setActiveTab('trading');
              setIsTradeModalOpen(true);
            }}
            totalTradingVolumeUSD={totalTradingVolumeUSD}
            totalTaxRemittedUSD={totalTaxRemittedUSD}
            totalOwnerRevenueUSD={totalOwnerRevenueUSD}
            currentParticipant={currentParticipant}
            onOpenBiometricsModal={() => setIsBiometricsModalOpen(true)}
          />
        )}

        {activeTab === 'video-voice' && (
          <DirectVideoVoiceConnection
            currentParticipant={currentParticipant}
            onOpenBiometricsModal={() => setIsBiometricsModalOpen(true)}
          />
        )}

        {activeTab === 'information' && (
          <InformationExchange
            informationList={informationList}
            onAddInformation={handleAddInformation}
          />
        )}

        {activeTab === 'ideas-game' && (
          <IdeaGiftGame
            ideas={ideas}
            onAddIdea={handleAddIdea}
            onGiftTokensToIdea={handleGiftTokensToIdea}
          />
        )}

        {activeTab === 'trading' && (
          <ProductTrading
            products={products}
            orders={orders}
            currency={currency}
            onExecuteTrade={handleExecuteTrade}
            isTradeModalOpen={isTradeModalOpen}
            setIsTradeModalOpen={setIsTradeModalOpen}
          />
        )}

        {activeTab === 'expense-income' && (
          <ExpenseToIncome
            currency={currency}
          />
        )}

        {activeTab === 'banking' && (
          <BankConnectivity
            banks={banks}
            currency={currency}
            onAddBank={handleAddBank}
          />
        )}

        {activeTab === 'legal-compliance' && (
          <EthicalLegalLaws
            laws={COMPLIANCE_LAWS}
          />
        )}

        {activeTab === 'tax-clearance' && (
          <TaxGovernmentPortal
            taxRecords={taxRecords}
            currency={currency}
            onRemitTax={handleRemitTax}
          />
        )}

        {activeTab === 'owner-revenue' && (
          <OwnerRevenueAnalytics
            currency={currency}
            totalOwnerRevenueUSD={totalOwnerRevenueUSD}
          />
        )}

        {activeTab === 'procedure-guide' && (
          <ZebeneProcedureGuide />
        )}
      </main>

      {/* Biometric Thumb & Eye Registration Modal */}
      <BiometricRegistrationModal
        isOpen={isBiometricsModalOpen}
        onClose={() => setIsBiometricsModalOpen(false)}
        onCompleteRegistration={handleCompleteBiometricRegistration}
        currentParticipant={currentParticipant}
      />

      {/* Institutional Footer */}
      <Footer setActiveTab={setActiveTab} />
    </div>
  );
}
